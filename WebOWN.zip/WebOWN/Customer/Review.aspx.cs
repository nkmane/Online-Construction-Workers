﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;

public partial class Customer_Review : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)  // first time page load
        {
            txtDt.Text = DateTime.Now.ToString("dd-MMM-yyyy");

            if (Session["user"] == null)
                Response.Redirect("~/Account/Login.aspx");

        }
    }
    protected void btnAdd_Click(object sender, EventArgs e)
    {

        SqlConnection con = new SqlConnection(HiddenField1.Value);
        SqlCommand cmd =
 new SqlCommand("insert into customerreview(OnDate,CustomerUN,WorkType,MukadamUN,Review) values(@OnDate,@CustomerUN,@WorkType,@MukadamUN,@Review)", con);

        cmd.Parameters.AddWithValue("@OnDate", txtDt.Text);
        cmd.Parameters.AddWithValue("@WorkType", ddlWT.Text);

        cmd.Parameters.AddWithValue("@MukadamUN", ddlMukadam.Text);
        cmd.Parameters.AddWithValue("@CustomerUN", Session["user"].ToString());
        cmd.Parameters.AddWithValue("@Review", txtRvw.Text);

        try
        {
            con.Open();
            if (cmd.ExecuteNonQuery() > 0)
            {
                lblMsg.Text = "Review Added";
                txtRvw.Text = "";

                GridView1.DataBind();
            }
            else
                lblMsg.Text = "Cannot Add Review";

            con.Close();
        }
        catch (Exception ex)
        {
            lblMsg.Text = "Error: " + ex.Message;
        }

    }
}