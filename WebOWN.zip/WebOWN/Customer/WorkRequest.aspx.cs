﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;

public partial class Customer_WorkRequest : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            txtDt.Text = DateTime.Now.ToString("dd-MMM-yyyy");

            if (Session["user"] == null)  // check for login
                Response.Redirect("~/Account/Login.aspx");
        }
    }
    
    protected void btnAddWR_Click(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(HiddenField1.Value);
        SqlCommand cmd = new SqlCommand("insert into customerwork(ondate,customerun,mukadamun,workdetails) values(@ondate,@customerun,@mukadamun,@workdetails)", con);
        cmd.Parameters.AddWithValue("@ondate", txtDt.Text);
        
        cmd.Parameters.AddWithValue("@customerun", Session["user"].ToString());
        cmd.Parameters.AddWithValue("@mukadamun", ddlMKDUN.Text );

        cmd.Parameters.AddWithValue("@workdetails", txtWDtls.Text);



        try
        {
            con.Open();
            if (cmd.ExecuteNonQuery() > 0)
            {
                lblMSG.Text = "Work Request Added";
                GridView1.DataBind();
            }
            else
                lblMSG.Text = "Cannot Add Work Request";

            con.Close();
        }
        catch (Exception ex)
        {
            lblMSG.Text = "Error: " + ex.Message;
        }
    }
}