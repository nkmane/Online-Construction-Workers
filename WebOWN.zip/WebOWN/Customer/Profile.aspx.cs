﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;

public partial class Customer_Profile : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)   // first page load
        {
            if (Session["user"] != null)  // check for login
            {
                lblUser.Text = Session["user"].ToString();
                LoadProfile(); // read table
            }
            else
                Response.Redirect("~/Account/Login.aspx");
        }
    }

    void LoadProfile()
    {
        SqlConnection con = new SqlConnection(HiddenField1.Value);
        SqlCommand cmd = 
       new SqlCommand("select * from customerprofile where username=@un", con);
        cmd.Parameters.AddWithValue("@un",lblUser.Text);
        try
        {
            con.Open();
            SqlDataReader dr = cmd.ExecuteReader();
            if (dr.Read())
            {
                txtFN.Text = dr["FullName"].ToString();
                txtST.Text = dr["Street"].ToString();
                txtLoc.Text = dr["Location"].ToString();
                txtMob.Text = dr["Mobile"].ToString();

            }
            else
                lblMSG.Text = "Record Not Found";


            con.Close();
        }
        catch (Exception ex)
        {

            lblMSG.Text = "Error: " + ex.Message;
        }
    }
    protected void btnUP_Click(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(HiddenField1.Value);
        SqlCommand cmd = 
            new SqlCommand("update CustomerProfile set FullName=@fn,street=@st,Location=@loc,Mobile=@mob where UserName=@un", con);
        cmd.Parameters.AddWithValue("@fn",txtFN.Text );
        cmd.Parameters.AddWithValue("@st", txtST.Text);
        cmd.Parameters.AddWithValue("@loc", txtLoc.Text);
        cmd.Parameters.AddWithValue("@mob", txtMob.Text);
        cmd.Parameters.AddWithValue("@un", lblUser.Text);

        try
        {
            con.Open();
            if (cmd.ExecuteNonQuery() > 0)
                lblMSG.Text = "Profile Updated";
            else
                lblMSG.Text = "Cannot Update Profile ";

            con.Close();
        }
        catch (Exception ex)
        {
            lblMSG.Text = "Error: " + ex.Message;
        }
    }
}