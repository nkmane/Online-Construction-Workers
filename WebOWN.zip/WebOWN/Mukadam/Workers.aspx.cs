﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;

public partial class Mukadam_Workers : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (Session["user"] == null)  // check for login
                Response.Redirect("~/Account/Login.aspx");
        }
    }
    protected void btnUP_Click(object sender, EventArgs e)
    {
 SqlConnection con = new SqlConnection(HiddenField1.Value);
 SqlCommand cmd = new SqlCommand("insert into workers(mukadamun,fullname,location,mobile) values(@mukadamun,@fullname,@location,@mobile)", con);
 cmd.Parameters.AddWithValue("@mukadamun", Session["user"].ToString());
 cmd.Parameters.AddWithValue("@fullname", txtFN.Text);
 cmd.Parameters.AddWithValue("@location", txtLoc.Text);
 cmd.Parameters.AddWithValue("@mobile", txtMob.Text);


         
        try 
	    {	        
		    con.Open();
            if (cmd.ExecuteNonQuery() > 0)
            {
                lblMSG.Text = "Art Added";
               GridView1.DataBind();
            }
            else
                lblMSG.Text = "Cannot Add Art";

            con.Close();
	    }
	    catch (Exception ex)
	    {
            lblMSG.Text = "Error: " + ex.Message;
	    }
    }
}