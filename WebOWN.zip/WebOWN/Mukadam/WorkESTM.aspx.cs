﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;

public partial class Mukadam_WorkESTM : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        txtDt.Text = DateTime.Now.ToString("dd-MMM-yyyy");

        if (!IsPostBack)   // first page load
        {
            if (Session["user"] == null)  // check for login
                Response.Redirect("~/Account/Login.aspx");
        }
    }
    protected void btnAddWE_Click(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(HiddenField1.Value);
        SqlCommand cmd = new SqlCommand("insert into Mukadamestm(ondate,cwid,mukadamun,estmamt,description) values(@ondate,@cwid,@mukadamun,@estmamt,@description)", con);
        cmd.Parameters.AddWithValue("@ondate", txtDt.Text);
        cmd.Parameters.AddWithValue("@cwid", GridView1.SelectedValue.ToString());

        cmd.Parameters.AddWithValue("@mukadamun", Session["user"].ToString());
        cmd.Parameters.AddWithValue("@estmamt", txtAmt.Text);

        cmd.Parameters.AddWithValue("@description", txtDesc.Text);



        try
        {
            con.Open();
            if (cmd.ExecuteNonQuery() > 0)
            {
                lblMSG.Text = "Work Request Added";
                GridView1.DataBind();
                GridView2.DataBind();

            }
            else
                lblMSG.Text = "Cannot Add Work Request";

            con.Close();
        }
        catch (Exception ex)
        {
            lblMSG.Text = "Error: " + ex.Message;
        }
    }
    protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
    {
        lblWD.Text = GridView1.SelectedRow.Cells[6].Text;
    }
}