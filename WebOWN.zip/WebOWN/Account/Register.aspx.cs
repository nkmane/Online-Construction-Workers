﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;   // sql server

public partial class Account_Register : System.Web.UI.Page
{
    void AddUserToProfile(string user)
    {
        SqlConnection con = new SqlConnection(HiddenField1.Value);
        SqlCommand cmd = 
    new SqlCommand("insert into " + ddlRole.Text  + "profile(UserName) values(@un)",con);
        cmd.Parameters.AddWithValue("@un",user);
        try
        {
            con.Open();
            if (cmd.ExecuteNonQuery() > 0)
                lblMsg.Text = "User Added To Profile";
            else
                lblMsg.Text = "Cannot Add User To Profile";

            con.Close();
        }
        catch (Exception ex)
        {
            lblMsg.Text = "Error: " + ex.Message;
        }

    }
    protected void Page_Load(object sender, EventArgs e)
    {
        RegisterUser.ContinueDestinationPageUrl = Request.QueryString["ReturnUrl"];
    }

    protected void RegisterUser_CreatedUser(object sender, EventArgs e)
    {
        FormsAuthentication.SetAuthCookie(RegisterUser.UserName, false /* createPersistentCookie */);

        // add new user to selected role
        Roles.AddUserToRole(RegisterUser.UserName, ddlRole.Text);

        // save globally
        Session["user"] = RegisterUser.UserName;

        AddUserToProfile( RegisterUser.UserName);  //udf

        string continueUrl = RegisterUser.ContinueDestinationPageUrl;
        if (String.IsNullOrEmpty(continueUrl))
        {
            continueUrl = "~/";
        }
        Response.Redirect(continueUrl);
    }

}
